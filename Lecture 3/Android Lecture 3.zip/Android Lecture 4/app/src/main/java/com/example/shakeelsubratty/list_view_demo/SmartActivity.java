package com.example.shakeelsubratty.list_view_demo;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.ListView;
import android.widget.Toast;

/**
 * Created by shakeelsubratty on 12/02/2018.
 */

public class SmartActivity extends AppCompatActivity {
    
    private SmartAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_smart);
        setTitle("Smart: ListView");
        createSmartViews();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId())
        {
            case R.id.smart:
                Toast.makeText(this,"You're already here, stupid",Toast.LENGTH_SHORT).show();
                break;
            case R.id.stupid:
                startActivity(new Intent(this, StupidActivity.class));
                break;
            case R.id.add_views:
                long timer = -System.currentTimeMillis();
                adapter.addRows(500);
                timer += System.currentTimeMillis();
                Toast.makeText(this, "Took" + timer + "ms", Toast.LENGTH_SHORT).show();
                break;
        }
        return true;
    }

    public void createSmartViews()
    {
        ListView listView = findViewById(R.id.list_view);
        adapter = new SmartAdapter(getLayoutInflater());
        listView.setAdapter(adapter);
    }
}

package com.example.shakeelsubratty.list_view_demo;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

/**
 * Created by shakeelsubratty on 12/02/2018.
 */

public class SmartAdapter extends BaseAdapter
{
    private LayoutInflater inflater;
    private int count = 500;

    public SmartAdapter(LayoutInflater inflater)
    {
        this.inflater = inflater;
    }

    public void addRows(int n)
    {
        count += n;
        notifyDataSetChanged();
    }

    @Override
    public int getCount() {
        return count;
    }

    @Override
    public Object getItem(int i) {
        return i;
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        View v = view;

        if(v == null)
        {
            v = inflater.inflate(R.layout.list_item,viewGroup,false);
        }
        ((TextView)v.findViewById(R.id.message)).setText("Row " + (i + 1));
        return v;
    }
}

package com.example.shakeelsubratty.preferencesanddatabases;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import org.joda.time.DateTime;

import java.util.ArrayList;

/*
Activity to display a List of Tasks in the database
 */

public class TaskListActivity extends AppCompatActivity
{
    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_task_list);
        setTitle("Preferences and Databases Demo");

        Button writeButton = findViewById(R.id.write);
        Button readButton = findViewById(R.id.read);


        /*
           DEMO: Preferences
           Set up two buttons - one to save (write) preferences, and one to read them again.
         */


        writeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                //Create SharedPreferences object - this is where the saved data is stored.
                SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());

                //Create an Editor to insert key/value pairs into SharedPreferences object
                SharedPreferences.Editor editor = prefs.edit();

                //Insert key/value pairs
                editor.putInt("user_highscore", 9999);
                editor.putBoolean("game_finshed", true);
                editor.putString("notification_alert_sound", "bells");

                //IMPORTANT - saves data to SharedPreferences object
                editor.apply();
            }
        });

        readButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                //Create SharedPreferences object - this is where the saved data is stored.
                SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());

                //Read stored data from SharedPreferences object
                int highScore = prefs.getInt("user_highscore",0);
                boolean gameFinished = prefs.getBoolean("game_finished", false);
                String notificationSound = prefs.getString("notification_alert_sound", "default");

                //Do something with them
                Toast.makeText(TaskListActivity.this, "Values: " + highScore + " " + gameFinished + " " + notificationSound, Toast.LENGTH_LONG).show();
            }
        });


        /**
         * DEMO: Database Insert
         */

        //Create some Task objects to insert into the database
        Task task1 = new Task("Buy milk", "The green one", false, DateTime.now());
        Task task2 = new Task("Buy bread", "Wholemeal", false, DateTime.now());
        Task task3 = new Task("Buy tickets", "", false, DateTime.now());

        //Create a Database Helper to make saving objects easy
        DbHelper dbHelper = new DbHelper(this);

        //Save tasks to database
        dbHelper.saveTask(task1);
        dbHelper.saveTask(task2);
        dbHelper.saveTask(task3);
    }


    @Override
    protected void onResume() {

        /**
         * DEMO: Database Read
         * Inside the onResume method so we can read the data at a different time to inserting it.
         * This could also be accomplished by using buttons for reading/writing to database, as shown with the Preferences demo
         */

        super.onResume();

        //Create a Database Helper to help us retrieve objects
        DbHelper dbHelper = new DbHelper(this);

        //Get incomplete tasks and store in an ArrayList
        ArrayList<Task> tasks = dbHelper.getIncompleteTasks();

        //Print them to Logcat
        for(Task t : tasks)
        {
            Log.d("KCLTechTodo", t.getId() + t.getTitle());
        }

    }
}
